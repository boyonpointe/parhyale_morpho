from cc3d.core.PySteppables import *
import numpy as np

class ConstraintInitializerSteppable(SteppableBasePy):
    def __init__(self,frequency=1):
        SteppableBasePy.__init__(self,frequency)
        
    def save_cellfield(self,fname):
        W,H = self.dim.x,self.dim.y 
        CF = np.zeros((2,W,H),dtype=np.uint8)
        for i in range(W):
            for j in range(H):
                cell = self.cellField[i,j,0]
                try:
                    CF[0,i,j] = int(cell.id)
                    CF[1,i,j] = int(cell.type)
                except:
                    print('')
        np.save(fname,CF)
        

    def start(self):
        self.niter = 0
        np.random.seed(self.niter)
        self.ofilename = '/Users/athena/CC3D_Output/phhpf26_NOrder_8_T50_dv01_JM_10_JSim_0_Jdiff_10_iter_'+str(self.niter)+'.npz'
        
        
        self.CellTypePerimeter = {}
        self.CellTypes = [self.BLUE,self.CYAN,self.MAGENTA,self.PINK,self.YELLOW,self.ORANGE]
        
        Color_to_CID = dict(np.load('/Users/athena/CompuCell3D/Simulations/parhyale_hpf26/Simulation/Color_to_Celltype.npz',allow_pickle=True))
        Cell_masks = np.load('/Users/athena/CompuCell3D/Simulations/parhyale_hpf26/Simulation/hpf26_masks_shrunk.npy')
        self.ncells = 0
        for color in Color_to_CID.keys():
            ct = color.upper()
            CIDS = Color_to_CID[color]
            for cid in CIDS:
                self.ncells += 1
                cell = self.newCell(eval('self.'+ct))
                
                y,x = np.nonzero(Cell_masks == cid)
                cx,cy = np.mean(x),np.mean(y)
                
                for m in range(y.size):
                    i_,j_ = int(y[m]),int(x[m])
                    self.cellField[j_,i_,0] = cell
                cell.targetVolume = cell.volume
                cell.targetSurface = cell.surface
                     
                cell.lambdaVolume = 1
                cell.lambdaSurface = 0.1 #change
                
        
        self.shared_steppable_vars['VTARGET'] = np.zeros(self.ncells)
        self.shared_steppable_vars['BDivAngles'] = []
        self.shared_steppable_vars['NBDivAngles'] = []
        
        
        Vols = []
        for j in range(1,self.ncells+1):
            cell_ = self.fetch_cell_by_id(j)
            vol_ = cell_.volume
            Vols.append(vol_)
            
            tarvol = vol_ + 100 #100 is a pretty good choice
            
            self.shared_steppable_vars['VTARGET'][j-1] = tarvol 
            
        print('total number of cells = ',self.ncells,len(self.cell_list))
        
        self.shared_steppable_vars['maxcells'] = 4 * self.ncells 
        print('max cells = ',self.shared_steppable_vars['maxcells'])
        
        self.shared_steppable_vars['minvol'] = np.min(Vols)
        print(np.max(Vols),np.min(Vols),np.mean(Vols),np.median(Vols))
    
    
    def step(self,mcs):
        if mcs%500 == 0:
            OverlapMat = np.zeros((6,6))
           
            for tid in range(6):
                total_surface = 0.0
                for cell_ in self.cell_list_by_type(self.CellTypes[tid]):
                    for nbr, com_surf in self.get_cell_neighbor_data_list(cell_):
                        if nbr:
                            if nbr.type != cell_.type:
                                OverlapMat[tid,nbr.type-1] += com_surf
                            
                
            
            self.CellTypePerimeter[str(mcs)] = OverlapMat/2
            
            if self.niter == 1:
                fname = '/Users/athena/CC3D_Output/Frame_NOrder_8_T50_phhpf26_JM_10_JSim_0_Jdiff_10_mcs_'+str(mcs)+'.npy'
                self.save_cellfield(fname)
                
            
            
            
    def finish(self):
        np.savez(self.ofilename,**self.CellTypePerimeter)
        D = {}
        D['BDiv'] = np.array(self.shared_steppable_vars['BDivAngles'])
        D['NBDiv'] = np.array(self.shared_steppable_vars['NBDivAngles'])
        np.savez('/Users/athena/CompuCell3D/Simulations/parhyale_hpf26/DivAngles.npz',**D)
        
        return None
        
        


    
                       
class GrowthSteppable(SteppableBasePy):
    def __init__(self,frequency=1):
        SteppableBasePy.__init__(self, frequency)
        self.dV = 0.01
    
    
    def step(self, mcs):
        ncells = len(self.cell_list)
        if ncells < self.shared_steppable_vars['maxcells']:
            VTARGET = self.shared_steppable_vars['VTARGET']
            
            for cell_ in self.cell_list_by_type(self.BLUE,self.CYAN,self.MAGENTA,self.PINK,self.YELLOW,self.ORANGE):
                j = cell_.id 
                if cell_.volume < VTARGET[j-1]:
                #if cell_.volume < 150:
                    cell_.targetVolume += np.random.normal(self.dV,self.dV/10)
                    cell_.targetSurface = np.sqrt(cell_.targetVolume/np.pi) * 2 * np.pi
                    
            
                   
class MitosisSteppable(MitosisSteppableBase):
    def __init__(self,frequency=1):
        MitosisSteppableBase.__init__(self,frequency)
        print(dir(self.cellOrientationPlugin))

    def step(self, mcs):
        ncells = len(self.cell_list)
        if ncells < self.shared_steppable_vars['maxcells']:
            cells_to_divide=[]
            VTARGET = self.shared_steppable_vars['VTARGET']
            
            for cell_ in self.cell_list_by_type(self.BLUE,self.CYAN,self.MAGENTA,self.PINK,self.YELLOW,self.ORANGE):
                j = cell_.id 
                if cell_.volume >= VTARGET[j-1] and cell_.volume >= self.shared_steppable_vars['minvol']:
                #if cell_.volume >= 150:    
                    cells_to_divide.append(cell_)
                     
    
            for cell in cells_to_divide:
                self.divide_cell_along_minor_axis(cell)
            

    def update_attributes(self):
        GroupDict = {1:-1,2:-1,5:-1,6:-1,3:-2,4:-2}
        
        # reducing parent target volume
        push = 1
        
        self.parent_cell.targetVolume /= 2.0                  

        self.clone_parent_2_child()            

        VT = self.shared_steppable_vars['VTARGET']
        
        
        pid = self.parent_cell.id 
        cid = self.child_cell.id 
        
        x1,y1,x2,y2 = self.parent_cell.xCOM,self.parent_cell.yCOM,self.child_cell.xCOM,self.child_cell.yCOM
        x_,y_ = 0.5*(x1+x2), 0.5*(y1+y2)
        angle = np.abs(np.arctan2(y2-y1,x2-x1))
        angle = np.pi/2 - np.abs(np.pi/2 - angle)
        angle = angle * (180/np.pi) 
        
        VT[pid-1] = self.parent_cell.volume + 100
        VT = np.concatenate([VT,[self.child_cell.volume + 100]])
        
        self.shared_steppable_vars['VTARGET'] = VT
        
        NbrType = []
        for cell_ in [self.parent_cell,self.child_cell]:
            for neighbor, common_surface_area in self.get_cell_neighbor_data_list(cell_):
                try:
                    NbrType.append(neighbor.type)
                except:
                    _ = 'do nothing'
        NbrType = np.array(NbrType)
        divCelltype = self.parent_cell.type
        NbrGroup = np.array([GroupDict[ele] for ele in NbrType])
        divCellgroup = GroupDict[divCelltype]
        
        if np.sum(NbrGroup != divCellgroup):
            self.shared_steppable_vars['BDivAngles'].append(angle)
        else:
            self.shared_steppable_vars['NBDivAngles'].append(angle)
            
        
        
        
        
        
        
        

        